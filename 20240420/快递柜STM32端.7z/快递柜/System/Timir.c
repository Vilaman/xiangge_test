#include "stm32f10x.h"                  // Device header

extern uint16_t Timir_count;

void Timir_Init(void)
{
    //使能TIM3时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);

    //初始化时基单元
    TIM_TimeBaseInitTypeDef Timir_struct;
    Timir_struct.TIM_ClockDivision=TIM_CKD_DIV1;//不分频
    Timir_struct.TIM_CounterMode=TIM_CounterMode_Up;//计数器模式 递增/递减/中心对齐
    Timir_struct.TIM_Period=65536-1;//周期ARR的值 10000个数
    Timir_struct.TIM_Prescaler=1-1;//PSC预分频的值72MHZ/7200=10000
    Timir_struct.TIM_RepetitionCounter=0;//重复计数计时器
    TIM_TimeBaseInit(TIM3,&Timir_struct);
    //清理标志位避免断电从1开始计数器是在出现更新事件发生后产生计数
    //防止更新事件和中断一起响应导致计数从1开始加而不是0
    
    
    GPIO_InitTypeDef PWM_GPIO;
    PWM_GPIO.GPIO_Mode=GPIO_Mode_IPU; //复用推挽输出 ;
    PWM_GPIO.GPIO_Pin= GPIO_Pin_5 |GPIO_Pin_6 ; //TIM_OC1Init 对应的是PA0;
    PWM_GPIO.GPIO_Speed=GPIO_Speed_50MHz;
    GPIO_Init(GPIOA,&PWM_GPIO);
    
    
    /*输入捕获初始化*/
    TIM_ICInitTypeDef TIM_ICInitStructure;//定义结构体变量
    TIM_ICStructInit(&TIM_ICInitStructure);//结构体初始化，若结构体没有完整赋值则最好执行此函数，给结构体所有成员都赋一个默认值
//避免结构体初值不确定的问题
    TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;//选择配置定时器通道1
    TIM_ICInitStructure.TIM_ICFilter = 0xF;//输入滤波器参数，可以过滤信号抖动
    TIM_ICInit(TIM3, &TIM_ICInitStructure);//将结构体变量交给TIM_ICInit，配置TIM3的输入捕获通道
    TIM_ICInitStructure.TIM_Channel = TIM_Channel_2;//选择配置定时器通道2
    TIM_ICInitStructure.TIM_ICFilter = 0xF;//输入滤波器参数，可以过滤信号抖动
    TIM_ICInit(TIM3, &TIM_ICInitStructure);//将结构体变量交给TIM_ICInit，配置TIM3的输入捕获通道
    
    /*编码器接口配置*/
    TIM_EncoderInterfaceConfig(TIM3, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);
    //配置编码器模式以及两个输入通道是否反相
    //注意此时参数的Rising和Falling已经不代表上升沿和下降沿了，而是代表是否反相
    //此函数必须在输入捕获初始化之后进行，否则输入捕获的配置会覆盖此函数的部分配置

    /*TIM使能*/
    TIM_Cmd(TIM3, ENABLE);//使能TIM3，定时器开始运行
}

int16_t Encoder_Get(void)
{
    /*使用Temp变量作为中继，目的是返回CNT后将其清零*/
    int16_t Temp;
    Temp = TIM_GetCounter(TIM3);
    return Temp;
}

