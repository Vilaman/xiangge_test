#ifndef __MY_RTC_H
#define __MY_RTC_H
#include "stm32f10x.h"                  // Device header


void MyRTC_Init(void);
uint32_t MyRTC_GetNowTime(void);
void MyRTC_SetTime(uint32_t sec);
void SetBasetime(int *TimeArr);




#endif
