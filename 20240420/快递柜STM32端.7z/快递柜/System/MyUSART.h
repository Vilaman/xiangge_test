#ifndef _MYUSART_H
#define _MYUSART_H
#include "stm32f10x.h"                  // Device header


void MyUsart_Init(void);
uint8_t Getrecvstatus(void);
char *Getdatarecv(void);
void Sendslbit(uint8_t data);
void SendArray(uint8_t *Array, uint16_t Length);
void Serial_SendStringln(char *String);

#endif
