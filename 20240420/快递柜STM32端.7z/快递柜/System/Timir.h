#ifndef _TIMIR_H
#define _TIMIR_H

void Timir_Init(void);
int16_t Encoder_Get(void);


#endif
