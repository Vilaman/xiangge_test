#ifndef __FLASH_H
#define __FLASH_H
#include "stm32f10x.h"                  // Device header


uint32_t MyFLASH_ReadWord(uint32_t Address);
uint16_t MyFLASH_ReadHalfWord(uint32_t Address);
uint8_t MyFLASH_ReadByte(uint32_t Address);
void Erase_Pagedata(uint32_t Address);
void WriteHalfWord_Flash(uint32_t Address,uint16_t Data);
void MyFlash_ArrInit(void);
void MyFlash_ArrSave(void);
uint16_t *GetFlashArr(void);


#endif
