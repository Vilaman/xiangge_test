#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include <stdarg.h>



char RxData[20]="";
uint8_t recvflag=0;

void MyUsart_Init(void)
{
    //开启RCC
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
    
    //
    USART_InitTypeDef MyUasart_initdef;
    MyUasart_initdef.USART_BaudRate=115200;//约定波特率
    MyUasart_initdef.USART_HardwareFlowControl=USART_HardwareFlowControl_None;//没有流控
    MyUasart_initdef.USART_Mode=USART_Mode_Tx | USART_Mode_Rx;//发送端口
    MyUasart_initdef.USART_Parity=USART_Parity_No;//没有校验位，odd 奇校验，even偶校验
    MyUasart_initdef.USART_StopBits=USART_StopBits_1;//一个停止位
    MyUasart_initdef.USART_WordLength=USART_WordLength_8b;//8位
    
    USART_Init(USART2,&MyUasart_initdef);
    
    //初始化发送GPIO
    GPIO_InitTypeDef MyUasartGPIO_initdef;
    MyUasartGPIO_initdef.GPIO_Mode=GPIO_Mode_AF_PP;//推挽式复用输出
    MyUasartGPIO_initdef.GPIO_Pin=GPIO_Pin_2;
    MyUasartGPIO_initdef.GPIO_Speed=GPIO_Speed_50MHz;
    GPIO_Init(GPIOA,&MyUasartGPIO_initdef);
    
//初始化接收口
    MyUasartGPIO_initdef.GPIO_Mode=GPIO_Mode_IPU;//上拉
    MyUasartGPIO_initdef.GPIO_Pin=GPIO_Pin_3;
    MyUasartGPIO_initdef.GPIO_Speed=GPIO_Speed_50MHz;
    GPIO_Init(GPIOA,&MyUasartGPIO_initdef);
    

    //开启中断接收
    USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);
    //配置NVIC
    
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    
    NVIC_InitTypeDef MyUsart_NVICDef;
    
    MyUsart_NVICDef.NVIC_IRQChannel=USART2_IRQn;
    MyUsart_NVICDef.NVIC_IRQChannelCmd=ENABLE;
    MyUsart_NVICDef.NVIC_IRQChannelPreemptionPriority=2;
    MyUsart_NVICDef.NVIC_IRQChannelSubPriority=2;
    NVIC_Init(&MyUsart_NVICDef);

    //开启USART
    USART_Cmd(USART2,ENABLE);

}


void Sendslbit(uint8_t data)
{
    USART_SendData(USART2,data);
//等一等发送完成
//0：数据还没有被转移到移位寄存器；
//1：数据已经被转移到移位寄存器。
    while(USART_GetFlagStatus(USART2,USART_FLAG_TXE)==RESET);
}

//传送数组
void SendArray(uint8_t *Array, uint16_t Length)
{
    for(uint16_t i=0;i<Length;i++)
    {
        Sendslbit(Array[i]);
    }

}

void Serial_SendStringln(char *String)
{
	for(uint8_t i = 0;String[i]!=0;i++)
	{
		Sendslbit(String[i]);
	}
	Sendslbit('\r');
	Sendslbit('\n');
}

void USART2_IRQHandler(void)
{

    if(USART_GetITStatus(USART2,USART_IT_RXNE)==SET)
    {
        static uint8_t recv_index=0;
        char recv_data=USART_ReceiveData(USART2);
        if(recv_data!='\r' && recv_data != '\n')
        {
            RxData[recv_index]=recv_data;
            recv_index++;
        }
        else if(recv_data=='\n')
        {
            RxData[recv_index]='\0';
            recv_index=0;
            recvflag=1;
            
        }
        USART_ClearITPendingBit(USART2,USART_IT_RXNE);
    }
}

//判断是否发送完成
uint8_t Getrecvstatus(void)
{   
    return recvflag;
}

char *Getdatarecv(void)
{
    recvflag=0;
    return RxData;
}

