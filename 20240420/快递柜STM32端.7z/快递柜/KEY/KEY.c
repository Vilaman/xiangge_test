#include "stm32f10x.h"
#include "Delay.h"



void KEY_init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); // 设置RCC时钟
 
    GPIO_InitTypeDef GPIO_InitStructure;
    
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; // 设置为上拉输入模式
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_10; // 设置初始化B0引脚
    
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    
    GPIO_Init(GPIOB, &GPIO_InitStructure); // GPIO初始化
}

uint8_t KEY_Get_Right(void)
{
    if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)==0){
        Delay_ms(10);
        while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)==0);
        Delay_ms(10);
        return 1;
    }
    else
        return 0;
}


uint8_t KEY_Get_Left(void)
{
    if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_10)==0){
        Delay_ms(10);
        while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_10)==0);
        Delay_ms(10);
        return 1;
    }
    else
        return 0;
}
