#ifndef __KEY_H
#define __KEY_H
#include "stm32f10x.h"                  // Device header



void KEY_init(void);
uint8_t KEY_Get_Right(void);
uint8_t KEY_Get_Left(void);

#endif
