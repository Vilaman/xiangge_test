#include "stm32f10x.h"                  // Device header
#include "OpenBox.h"
#include "OLED.h"
#include "MyUSART.h"
#include "Delay.h"
#include "OLED.h"
#include "string.h"






int main(void)
{   
    
   Open_Box_Init();
    while(1)
    {   
        OLED_Clear();
      
        if(Getrecvstatus()==1)
        {
            char *recvdata=Getdatarecv();
            OLED_ShowString(1,1,recvdata);
            Delay_ms(300);
            if(strcmp(recvdata,Claim_box1)==0)
            {
                GPIO_WriteBit(GPIOA,Claim_Box1,Bit_SET);
                Delay_ms(3000);
                GPIO_WriteBit(GPIOA,Claim_Box1,Bit_RESET);
            }
            else if(strcmp(recvdata,Claim_box2)==0)
            {
                GPIO_WriteBit(GPIOA,Claim_Box2,Bit_SET);
                Delay_ms(3000);
                GPIO_WriteBit(GPIOA,Claim_Box2,Bit_RESET);
            }
            else if(strcmp(recvdata,Claim_box3)==0)
            {
                GPIO_WriteBit(GPIOA,Claim_Box3,Bit_SET);
                Delay_ms(3000);
                GPIO_WriteBit(GPIOA,Claim_Box3,Bit_RESET);
            }
            else if(strcmp(recvdata,Claim_box4)==0)
            {
                GPIO_WriteBit(GPIOA,Claim_Box4,Bit_SET);
                Delay_ms(3000);
                GPIO_WriteBit(GPIOA,Claim_Box4,Bit_RESET);
        }
    
    }

    }
}


