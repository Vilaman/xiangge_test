#include "stm32f10x.h"                  // Device header
#include "MyIIC.h"
#include "Delay.h"
#include "My_OLED_Font.h"
#include "string.h"

#define OLED_Adress 0x78




void OLED_SendCommand(uint8_t data)
{
    I2C_Start();
    //发送OLED地址
    MyI2C_SendByte(OLED_Adress);
    //读取OLED响应ACK
    MyI2C_ReadACK();
    //发送Control byte0(CO)0(DC)000000
    MyI2C_SendByte(0x00);
     //读取OLED响应ACK
    MyI2C_ReadACK();
    //发送命令
    MyI2C_SendByte(data);
     //读取OLED响应ACK
    MyI2C_ReadACK();
    I2C_Stop();
}
//指定数据显示在什么地方
//page 0-7  2=00000010
//colomn  0-127
//假设传入的地址是127，对应的二进市应该是01111111，高四位是0111，低四位是1111
//高四位和低四位要分开传，
//设置显示位置
void OLED_Location(uint8_t page,uint8_t colum)
{
    OLED_SendCommand(0xB0 | page);
    //设置高位
    OLED_SendCommand((colum>>4) | 0x10);
     //设置低位
    OLED_SendCommand((colum&0x0F) | 0x00);
}


//发送显示的数据
void OLED_SendData(uint8_t *data,uint16_t start,uint16_t length)
{
    I2C_Start();
    //发送OLED地址
    MyI2C_SendByte(OLED_Adress);
    //读取OLED响应ACK
    MyI2C_ReadACK();
    //发送Control byte0(CO)1(DC)000000
    MyI2C_SendByte(0x40);
     //读取OLED响应ACK
    MyI2C_ReadACK();
    for(uint16_t i=start;i<length+start;i++)
    {
        //发送指令
        MyI2C_SendByte(data[i]);
        MyI2C_ReadACK();
    }
    I2C_Stop();
}

void OLED_ShowImage(uint8_t page,uint8_t colomn,uint8_t *Bytes,uint8_t high,uint8_t width)
{
    uint8_t i;
    for(i=0;i<high/8;i++)
    {
            OLED_Location(page+i,colomn);
            OLED_SendData(Bytes,i*width,width);
    }
}

//显示字符
void ShowChar(uint8_t line,uint8_t colum,uint8_t SL_char)
{
    OLED_ShowImage(2*(line-1),(colum-1)*8,OLED_Font[SL_char-' '],16,8);
}

void ShowString(uint8_t line,uint8_t colum,char *str)
{
    uint8_t i=0;
    while(str[i]!='\0')
    {
        ShowChar(line,colum+i,str[i]);
        i++;
    }

}
//获取传入int型数的长度
uint8_t OLED_GetNumLength(int num)
{
    uint8_t length=0;
    while(num>0)
    {
        num/=10;
        length++;
    }
    return length;
}

//计算该数的pow
int OLED_GetPow(uint8_t length,uint8_t pow)
{
    int num=1;
    while(length>0)
    {
        num*=pow;
        length--;
    }
    return num;
}
//显示int整数
void ShowNum(uint8_t line,uint8_t colum,int num)
{
    uint8_t idx=0;//定义宽度
    if(num<0)//当num为负数时
    {
        idx=1;
        ShowChar(line,colum,'-');
        num*=-1;
    }
    uint8_t length=OLED_GetNumLength(num);
    uint8_t i;
    for(i=length;i>0;i--)
    {
        ShowChar(line,colum+idx,num/OLED_GetPow(i-1,10)%10+'0');
        idx++;
    }
}

//显示中文
/*void ShowChinese(uint8_t line,uint8_t colum,char *chinesedata)
{
    //因为UTF_8是四个字节
    uint8_t chinesearr[4]={0};
    for(uint8_t i=0;chinesedata[i]!=0;i+=3)
    {
        chinesearr[0]=(uint8_t)chinesedata[i];
        chinesearr[1]=(uint8_t)chinesedata[i+1];
        chinesearr[2]=(uint8_t)chinesedata[i+2];
        for(uint8_t j=0;j<5;j++)
        {
            if(strcmp((const char *)chinesearr,Chinsefont[j].Chinesedata)==0)
            {
                OLED_ShowImage(2*(line-1),(colum-1)*16+i/3*16,Chinsefont[j].Imagedata,16,16);
            }
        }
    }
}*/


//清除屏幕
void OLED_Clear(void)
{
    uint8_t data[128] = {0x00};
    for(uint8_t i=0;i<8;i++)
    {
        OLED_Location(i,0);
        OLED_SendData(data,0,128);
    }

}
//初始化OLED
void My_OLED_Init(void)
{
    Delay_ms(100);
    MyI2C_Init();
    
    OLED_SendCommand(0xAE);
    
    OLED_SendCommand(0xD5);
    OLED_SendCommand(0x80);
    
    OLED_SendCommand(0xA8);
    OLED_SendCommand(0x3F);
    
    OLED_SendCommand(0xD3);
    OLED_SendCommand(0x00);
    
    OLED_SendCommand(0x40);
    
    OLED_SendCommand(0xA1);
    
    OLED_SendCommand(0xC8);
    
    OLED_SendCommand(0xDA);
    OLED_SendCommand(0x12);
    
    OLED_SendCommand(0x81);
    OLED_SendCommand(0xCF);
    
    OLED_SendCommand(0xD9);
    OLED_SendCommand(0xF1);
    
    OLED_SendCommand(0xDB);
    OLED_SendCommand(0x30);
    
    OLED_SendCommand(0xA4);
    
    OLED_SendCommand(0xA6);
    
    OLED_SendCommand(0x8D);
    OLED_SendCommand(0x14);
    
    OLED_SendCommand(0xAF);
    
    OLED_Clear();
}
