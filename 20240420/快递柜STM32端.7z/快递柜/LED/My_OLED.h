#ifndef _MY_OLED_H
#define _MY_OLED_H
#include "stdint.h"

void My_OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowImage(uint8_t page,uint8_t colomn,uint8_t *Bytes,uint8_t high,uint8_t width);
void ShowChar(uint8_t line,uint8_t colum,uint8_t SL_char);
void ShowString(uint8_t line,uint8_t colum,char *str);
void ShowNum(uint8_t line,uint8_t colum,int num);
void ShowChinese(uint8_t line,uint8_t colum,char *chinesedata);

#endif
