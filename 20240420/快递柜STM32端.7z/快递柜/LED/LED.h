#ifndef __LED_H
#define __LED_H


void LED_init(void);
void LED_ON(void);
void LED_OFF(void);
void LED_Pressonce(void);

#endif
