#include "stm32f10x.h"



void LED_init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); // 设置RCC时钟
 
    GPIO_InitTypeDef GPIO_InitStructure;
    
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; // 设置为推挽输出模式
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0; // 设置初始化A0引脚
    
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    
    GPIO_Init(GPIOA, &GPIO_InitStructure); // GPIO初始化
}

void LED_ON(void)
{
    GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_SET);
}

void LED_OFF(void)
{
    GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
}

void LED_Pressonce(void){
    if(GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_0)==0)
    {
        LED_ON();
    }
    else
    {
        LED_OFF();
    }

}
