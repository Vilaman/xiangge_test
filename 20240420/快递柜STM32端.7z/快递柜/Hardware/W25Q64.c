#include "stm32f10x.h"                  // Device header
#include "My_SPI.h"
#include "W25Q64_CMD.h"
#include "W25Q64.h"
#include "My_OLED.h"
#include "Delay.h"
#include <stdio.h>
#include <stdlib.h>




void W25Q64_Init(void)
{
    MySPI_Init();

}

//��״̬�Ĵ���
uint8_t Read_W25Q64SR1(void)
{
    SPI_Start();//��ʼͨ��
    //����״̬����
    SPI_SwapByte(Read_SR1);
    //��������ֵ��ȡ״̬
    uint8_t SR1_Data=SPI_SwapByte(Swap_Data);
    SPI_Stop();
    return SR1_Data;
}

/*��ȡоƬ����
Address��ʾ��оƬλ��
length ��ʾҪ���೤
*/

uint8_t * ReadData_W25Q64(uint32_t Address,uint16_t length)
{
    //�ȴ�SR״̬Ϊ0
    while((Read_W25Q64SR1()&0x01)!=0);
    uint8_t *Data=(uint8_t *)malloc(length * sizeof(uint8_t));
    if(Data==NULL)
    {
        perror("malloc");
    }
    
    SPI_Start();//��ʼͨ��
    //���Ͷ�ȡ��������
    SPI_SwapByte(Read_Data);
    //���͵�ַ
    SPI_SwapByte((uint8_t)(Address>>16));
    SPI_SwapByte((uint8_t)(Address>>8));
    SPI_SwapByte((uint8_t)Address);
    //������
    for(uint16_t i=0;i<length;i++)
    {
        Data[i]=SPI_SwapByte(Swap_Data);
    }
    SPI_Stop();
    return Data;
}

//��������
void Erase_Data(uint32_t Address,uint8_t Erase_Size)
{
    //�ȴ�SR״̬Ϊ0
    while((Read_W25Q64SR1()&0x01)!=0);
    SPI_Start();//��ʼͨ��
    //дʹ��
    SPI_SwapByte(Write_Enable);
    SPI_Stop();
    while((Read_W25Q64SR1()&0x03)!=0x02);
    SPI_Start();//��ʼͨ��
    SPI_SwapByte(Erase_Size);
    //���͵�ַ
    if(Erase_Size!=Chip_Erase)
    {
        SPI_SwapByte((uint8_t)(Address>>16));
        SPI_SwapByte((uint8_t)(Address>>8));
        SPI_SwapByte((uint8_t)Address);
    }
    SPI_Stop();
}

//д����
void WriteData_W25Q64(uint32_t Address,uint8_t *data,uint16_t length)
{
    //�ȴ�SR״̬Ϊ0
    while((Read_W25Q64SR1()&0x01)!=0);
    SPI_Start();//��ʼͨ��
    //дʹ��
    SPI_SwapByte(Write_Enable);
    SPI_Stop();
    while((Read_W25Q64SR1()&0x03)!=0x02);
    SPI_Start();//��ʼͨ��
    SPI_SwapByte(Page_Program);
    //���͵�ַ
    SPI_SwapByte((uint8_t)(Address>>16));
    SPI_SwapByte((uint8_t)(Address>>8));
    SPI_SwapByte((uint8_t)Address);
    for(uint16_t i=0;i<length&&i<=256;i++)
    {
        SPI_SwapByte(data[i]);
    }
    SPI_Stop();
}

//��Ϊʹ����malloc��̬�����ڴ�,���Ҫʹ��free�ͷſռ�
void Free_Memery(uint8_t *data)
{
    free(data);
    data=NULL;
}

/*void show_Kun(void)
{   
    static uint32_t Adress_Start=0x000000;
    for(uint16_t i=0;i<300;i++)
    {   
        OLED_Clear();
        uint8_t * Data=ReadData_W25Q64(Adress_Start,256);
        OLED_ShowImage(2,30,Data,32,64);
        Free_Memery(Data);
        Adress_Start+=0xFF;
        Delay_ms(30);
        if(i==299)
        {
            Adress_Start=0x000000;
        }
    }

}
*/


