#include "stm32f10x.h"                  // Device header

void MyADC_init(void)
{
    //使能ADC1和GPIO口
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1,ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
    
    /*设置ADC时钟*/
    //选择时钟6分频，ADCCLK = 72MHz / 6 = 12MHz  最大不能超过14MHz
    RCC_ADCCLKConfig(RCC_PCLK2_Div6);
    
    
    GPIO_InitTypeDef ADC_GPIO_Init;
    ADC_GPIO_Init.GPIO_Mode=GPIO_Mode_AIN;//将PA0引脚初始化为模拟输入
    ADC_GPIO_Init.GPIO_Pin=GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    ADC_GPIO_Init.GPIO_Speed=GPIO_Speed_50MHz;
    
    GPIO_Init(GPIOA,&ADC_GPIO_Init);
    

    
    //ADC初始化
    ADC_InitTypeDef ADC_init_my;
    ADC_init_my.ADC_ContinuousConvMode=ENABLE;//连续转换
    ADC_init_my.ADC_DataAlign=ADC_DataAlign_Right;//数据对齐，选择右对齐
    ADC_init_my.ADC_ExternalTrigConv=ADC_ExternalTrigConv_None;//外部触发，使用软件触发，不需要外部触发
    ADC_init_my.ADC_Mode=ADC_Mode_Independent;//模式，选择独立模式，即单独使用ADC1
    ADC_init_my.ADC_NbrOfChannel=4;//通道数，为1，仅在扫描模式下，才需要指定大于1的数，在非扫描模式下，只能是1
    ADC_init_my.ADC_ScanConvMode=ENABLE;//扫描模式，失能，只转换规则组的序列1这一个位置
    
    ADC_Init(ADC1,&ADC_init_my);
    
    ADC_RegularChannelConfig(ADC1, ADC_Channel_4, 1, ADC_SampleTime_55Cycles5);//规则组序列1的位置，配置为通道0
    ADC_RegularChannelConfig(ADC1, ADC_Channel_5, 2, ADC_SampleTime_55Cycles5);
    ADC_RegularChannelConfig(ADC1, ADC_Channel_6, 3, ADC_SampleTime_55Cycles5);
    ADC_RegularChannelConfig(ADC1, ADC_Channel_7, 4, ADC_SampleTime_55Cycles5);
    
    ADC_Cmd(ADC1, ENABLE);//使能ADC1
    
    //开启触发ADC_DMC
    ADC_DMACmd(ADC1,ENABLE);
    
    //ADC校准
    ADC_ResetCalibration(ADC1);//内部有电路会自动执行校准
    while (ADC_GetResetCalibrationStatus(ADC1) == SET);
    ADC_StartCalibration(ADC1);
    while (ADC_GetCalibrationStatus(ADC1) == SET);
    
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);//软件触发AD转换

}


