#ifndef _MY_TFT_SPI_H
#define _MY_TFT_SPI_H
#include "stm32f10x.h"                  // Device header


void TFT_MySPI_Init(void);
void TFT_SPI_Start(void);
void TFT_SPI_Stop(void);
void SPI_CS_Write(uint8_t Bit);
void SPI_SCL_Write(uint8_t Bit);
void SPI_SDA_Write(uint8_t Bit);
void SPI_RST_Write(uint8_t Bit);
void SPI_DC_Write(uint8_t Bit);
void TFT_SPI_SendByte(uint8_t Byte);


#endif
