#ifndef _W25Q64_H
#define _W25Q64_H
#include "stm32f10x.h"                  // Device header

#define max 100

uint8_t Read_W25Q64SR1(void);
uint8_t * ReadData_W25Q64(uint32_t Address,uint16_t length);
void Erase_Data(uint32_t Address,uint8_t Erase_Size);
void WriteData_W25Q64(uint32_t Address,uint8_t *data,uint16_t length);
void W25Q64_Init(void);
void Free_Memery(uint8_t *data);
void show_Kun(void);




#endif
