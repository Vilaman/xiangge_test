#ifndef _MPU6050_H
#define _MPU6050_H

typedef struct MPU6050_DataTypeDef
{
    int16_t ACCEL_X;
    int16_t ACCEL_Y;
    int16_t ACCEL_Z;
    int16_t GYRO_X;
    int16_t GYRO_Y;
    int16_t GYRO_Z;
}MPU6050_DataTypeDef;


void MPU6050_Init(void);
void MPU6050_WriteADDR(uint8_t RegADDR,uint8_t data);
uint8_t MPU6050_ReadADDR(uint8_t RegADDR);
void MPU6050_Data(MPU6050_DataTypeDef *data);

#endif
