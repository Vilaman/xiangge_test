#ifndef _MY_SPI_H
#define _MY_SPI_H
#include "stm32f10x.h"                  // Device header


void MySPI_Init(void);
void SPI_Start(void);
void SPI_Stop(void);
uint8_t SPI_SwapByte(uint8_t Byte);


#endif
