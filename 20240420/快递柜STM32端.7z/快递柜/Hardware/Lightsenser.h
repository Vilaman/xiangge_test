#ifndef __LIGHTSENSER_H
#define __LIGHTSENSER_H


void Lightsenser_init(void);
uint8_t LightStatusGet(void);

#endif
