#include "stm32f10x.h"                  // Device header
#include "My_TFT_SPI.h"
#include "Delay.h"
#include "TFT_Color.h"





//��λ����
void TFT_Reset(void)
{
    SPI_RST_Write(1);
    Delay_ms(100);
    SPI_RST_Write(0);
    Delay_us(20);
    SPI_RST_Write(1);
    Delay_ms(130);
}

//����ָ��
void TFT_Sendcommand(uint8_t command)
{
    TFT_SPI_Start();
    SPI_DC_Write(0);//DC�͵�ƽ��ʾ��������ģʽ
    TFT_SPI_SendByte(command);
    TFT_SPI_Stop();
}

//�������ݻ��߲���
void TFT_SendData(uint8_t data)
{
    TFT_SPI_Start();
    SPI_DC_Write(1);//DC�ߵ�ƽ��ʾ�������ݻ��߲���
    TFT_SPI_SendByte(data);
    TFT_SPI_Stop();
}


//���Ͷ������
void TFT_SendDatas(uint8_t *data,uint16_t start,uint16_t length)
{
    TFT_SPI_Start();
    SPI_DC_Write(1);//DC�ߵ�ƽ��ʾ�������ݻ��߲���
    for(uint16_t i=0;i<start+length;i++)
    {
        TFT_SPI_SendByte(data[i]);
    }
    TFT_SPI_Stop();
}

//����λ��
void Set_TFTArea(uint8_t ColoumnStart,uint8_t ColoumnEnd,uint8_t LineStart,uint8_t LineEnd)
{
    //������λ��
    TFT_Sendcommand(Set_Column);
    //�����п�ʼ�߰�λ
    TFT_SendData(0x00);
     //�����п�ʼ�Ͱ�λ
    TFT_SendData(ColoumnStart);
     //�����н����߰�λ
    TFT_SendData(0x00);
     //�����н����Ͱ�λ
    TFT_SendData(ColoumnEnd-1);
    //������λ��
    TFT_Sendcommand(Set_Line);
    //�����п�ʼ�߰�λ
    TFT_SendData(0x00);
     //�����п�ʼ�Ͱ�λ
    TFT_SendData(LineStart);
     //�����н����߰�λ
    TFT_SendData(0x00);
     //�����н����Ͱ�λ
    TFT_SendData(LineEnd-1);
}

//��ʾͼƬ
void TFT_ShowImage(uint8_t coloumn,uint8_t line,uint8_t ImgHigh,uint8_t ImgWidth,uint8_t * Data)
{
    Set_TFTArea(coloumn,coloumn+ImgWidth,line,line+ImgHigh);
    TFT_Sendcommand(Set_ShowMemery);
    TFT_SendDatas(Data,0,ImgHigh*ImgWidth*2);
}

//���ƴ�ɫ����
void SetFill_Color(uint8_t coloumn,uint8_t row,uint8_t Heigth, uint8_t Width,uint16_t Color)
{
    Set_TFTArea(coloumn,coloumn+Width,row,row+Heigth);
    TFT_Sendcommand(Set_ShowMemery);
    for(uint16_t i=0;i<Heigth*Width;i++)
    {
        //һ����ɫҪд�����ֽ�
        TFT_SendData(Color>>8);   //��8λ
        TFT_SendData(Color);   //��8λ
    }

}

//����
void TFT_clear(void)
{
    SetFill_Color(0,0,160,128,WHITE);
}



//��ʼ����Ļ

void TFT_Init(void)
{
    TFT_MySPI_Init();
    TFT_Reset();
    //--------------------------------End ST7735S Reset Sequence --------------------------------------//
	TFT_Sendcommand(0x11); //Sleep out
	Delay_ms(120);              //Delay 120ms
//------------------------------------ST7735S Frame Rate-----------------------------------------//
	TFT_Sendcommand(0xB1);
	TFT_SendData(0x05);
	TFT_SendData(0x3C);
	TFT_SendData(0x3C);
	TFT_Sendcommand(0xB2);
	TFT_SendData(0x05);
	TFT_SendData(0x3C);
	TFT_SendData(0x3C);
	TFT_Sendcommand(0xB3);
	TFT_SendData(0x05);
	TFT_SendData(0x3C);
	TFT_SendData(0x3C);
	TFT_SendData(0x05);
	TFT_SendData(0x3C);
	TFT_SendData(0x3C);
//------------------------------------End ST7735S Frame Rate---------------------------------//
	TFT_Sendcommand(0xB4); //Dot inversion
	TFT_SendData(0x03);
//------------------------------------ST7735S Power Sequence---------------------------------//
	TFT_Sendcommand(0xC0);
	TFT_SendData(0x28);
	TFT_SendData(0x08);
	TFT_SendData(0x04);
	TFT_Sendcommand(0xC1);
	TFT_SendData(0XC0);
	TFT_Sendcommand(0xC2);
	TFT_SendData(0x0D);
	TFT_SendData(0x00);
	TFT_Sendcommand(0xC3);
	TFT_SendData(0x8D);
	TFT_SendData(0x2A);
	TFT_Sendcommand(0xC4);
	TFT_SendData(0x8D);
	TFT_SendData(0xEE);
//---------------------------------End ST7735S Power Sequence-------------------------------------//
	TFT_Sendcommand(0xC5); //VCOM
	TFT_SendData(0x1A);
	TFT_Sendcommand(0x36); //MX, MY, RGB mode
	TFT_SendData(0xC0);
//------------------------------------ST7735S Gamma Sequence---------------------------------//
	TFT_Sendcommand(0xE0);
	TFT_SendData(0x04);
	TFT_SendData(0x22);
	TFT_SendData(0x07);
	TFT_SendData(0x0A);
	TFT_SendData(0x2E);
	TFT_SendData(0x30);
	TFT_SendData(0x25);
	TFT_SendData(0x2A);
	TFT_SendData(0x28);
	TFT_SendData(0x26);
	TFT_SendData(0x2E);
	TFT_SendData(0x3A);
	TFT_SendData(0x00);
	TFT_SendData(0x01);
	TFT_SendData(0x03);
	TFT_SendData(0x13);
	TFT_Sendcommand(0xE1);
	TFT_SendData(0x04);
	TFT_SendData(0x16);
	TFT_SendData(0x06);
	TFT_SendData(0x0D);
	TFT_SendData(0x2D);
	TFT_SendData(0x26);
	TFT_SendData(0x23);
	TFT_SendData(0x27);
	TFT_SendData(0x27);
	TFT_SendData(0x25);
	TFT_SendData(0x2D);
	TFT_SendData(0x3B);
	TFT_SendData(0x00);
	TFT_SendData(0x01);
	TFT_SendData(0x04);
	TFT_SendData(0x13);
//------------------------------------End ST7735S Gamma Sequence-----------------------------//
	TFT_Sendcommand(0x3A); //65k mode
	TFT_SendData(0x05);
	TFT_Sendcommand(0x29); //Display on
    TFT_clear();

}
