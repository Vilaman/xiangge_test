#include "stm32f10x.h"                  // Device header
#include "MyUSART.h"
#include "Delay.h"
#include "OLED.h"
#include "OpenBox.h"



void Open_Box_Init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
    GPIO_InitTypeDef OpenBoxGPIO_initdef;
    OpenBoxGPIO_initdef.GPIO_Mode=GPIO_Mode_Out_PP;
    OpenBoxGPIO_initdef.GPIO_Pin=Claim_Box1 | Claim_Box2 | Claim_Box3 | Claim_Box4;
    OpenBoxGPIO_initdef.GPIO_Speed=GPIO_Speed_50MHz;
    GPIO_Init(GPIOA,&OpenBoxGPIO_initdef);
    MyUsart_Init();
    OLED_Init();

}

