#include "stm32f10x.h"                  // Device header
#include "Delay.h"

//初始化
void MyI2C_Init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
    
    GPIO_InitTypeDef MyI2CGPIO;
    MyI2CGPIO.GPIO_Mode=GPIO_Mode_Out_OD;
    MyI2CGPIO.GPIO_Pin=GPIO_Pin_8 | GPIO_Pin_9;//SCL,SDA
    MyI2CGPIO.GPIO_Speed=GPIO_Speed_50MHz;
    
    GPIO_Init(GPIOB,&MyI2CGPIO);
    
    //先把SDA和SCL的电平拉高
    GPIO_WriteBit(GPIOB,GPIO_Pin_8,(BitAction)1);
    GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)1);
}

//改变SCL电平的跳变状态函数

void My_I2C_SCLWrite(uint8_t bit)
{
    GPIO_WriteBit(GPIOB,GPIO_Pin_8,(BitAction)bit);
    Delay_us(10);
}

//改变SDA电平的跳变状态函数
void My_I2C_SDAWrite(uint8_t bit)
{
    GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)bit);
    Delay_us(10);
}

//读取SDA的数据信息
uint8_t MyI2C_ReadBit(void)
{
    uint8_t bit;
    bit=GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9);
    Delay_us(10);
    return bit;
}

//开始操作
void I2C_Start(void)
{
//SCL高电平期间，SDA从高电平切换到低电平
    My_I2C_SDAWrite(1);//释放SDA，确保SDA为高电平
    My_I2C_SCLWrite(1);//释放SCL，确保SCL为高电平
    My_I2C_SDAWrite(0);//在SCL高电平期间，拉低SDA，产生起始信号
//钳住SCL线准备接下来的发送
//因为主机将SCL拉低再放数据在SDA上面    
    My_I2C_SCLWrite(0);
}

//终止操作
void I2C_Stop(void)
{
//SCL高电平期间，SDA从低电平切换到高电平
    My_I2C_SDAWrite(0);//拉低SDA，确保SDA为低电平
    My_I2C_SCLWrite(1);//释放SCL，使SCL呈现高电平
    My_I2C_SDAWrite(1);//在SCL高电平期间，释放SDA，产生终止信号
}


//发送一个字节
void MyI2C_SendByte(uint8_t data)
{
    for(uint8_t i=0;i<8;i++)
    {
//        My_I2C_SDAWrite((data&0x80)>>7);
        My_I2C_SDAWrite(data&(0x80>>i));//放入数据线; 有0的时候才写入0；其他值都写入1；
        My_I2C_SCLWrite(1);//释放SCL，从机在SCL高电平期间读取SDA
        My_I2C_SCLWrite(0);//拉低SCL，主机开始发送下一位数据
//        data<<=1; /* 左移1位, 用于下一次发送 */
    }

}

//主机接收一个字节
uint8_t MyI2C_RecvByte(void)
{
    My_I2C_SDAWrite(1);//先释放SDA让从机写
    uint8_t data=0x00;
    for(uint8_t i=0;i<8;i++)
    {
        My_I2C_SCLWrite(1);//释放SCL准备读取SDA
        if(MyI2C_ReadBit()==1)
        {
            data |= 0x80>>i;
        }
        My_I2C_SCLWrite(0);//SCL低电平
    }
    return data;
}

//主机发送ACK
void MyI2C_SendACK(uint8_t ACK)
{
    My_I2C_SDAWrite(ACK);
    My_I2C_SCLWrite(1);//设备读
    My_I2C_SCLWrite(0);//准备下一个时序
}





//接收从机应答信号
uint8_t MyI2C_ReadACK(void)
{
    //主机释放SCL 和 SDA让从机可以操作
    My_I2C_SDAWrite(1);//接收前，主机先确保释放SDA，避免干扰从机的数据发送
    My_I2C_SCLWrite(1);//释放SCL，主机机在SCL高电平期间读取SDA
  
    uint8_t ack=0;//定义应答位变量
    ack=MyI2C_ReadBit();//将应答位存储到变量里
    My_I2C_SCLWrite(0);//钳住SCL线为后续发送信息做准备
    return ack;
}


