#include "stm32f10x.h"                  // Device header

//定义一个变量观察
uint8_t count=0;

//初始化GPIO引脚
void Interrupt_Init(void)
{
    //使能GPIO
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
    GPIO_InitTypeDef GPIO_Interrupt;
    GPIO_Interrupt.GPIO_Mode=GPIO_Mode_IPU;
    GPIO_Interrupt.GPIO_Pin=GPIO_Pin_0;
    GPIO_Interrupt.GPIO_Speed=GPIO_Speed_50MHz;
    GPIO_Init(GPIOA,&GPIO_Interrupt);
    
    //使能AFIO时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
    //设置EXTI和IO对应关系
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource0);
    //设置EXTI屏蔽上下沿
    EXTI_InitTypeDef EXTI_Interrupt;//使用EXTI相关结构体
    EXTI_Interrupt.EXTI_Line=EXTI_Line0;//选择通道
    EXTI_Interrupt.EXTI_LineCmd=ENABLE;//开启通道
    EXTI_Interrupt.EXTI_Mode=EXTI_Mode_Interrupt;//选择中断
    EXTI_Interrupt.EXTI_Trigger=EXTI_Trigger_Rising_Falling;//上下沿触发
    EXTI_Init(&EXTI_Interrupt);
    //设置NVIC
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    //使用NVIC结构体
    NVIC_InitTypeDef NVIC_Interrupt;
    NVIC_Interrupt.NVIC_IRQChannel=EXTI0_IRQn;//选择要配置的中断通道
    NVIC_Interrupt.NVIC_IRQChannelCmd=ENABLE;//开启中断
    NVIC_Interrupt.NVIC_IRQChannelPreemptionPriority=0x2;//设置抢断优先级
    NVIC_Interrupt.NVIC_IRQChannelSubPriority=0x1;//设置响应优先级
    NVIC_Init(&NVIC_Interrupt); //初始化
    
}
//设计中断服务函数
void EXTI0_IRQHandler(void)
{
    //判断是否是EXTI0进来
    if(EXTI_GetITStatus(EXTI_Line0)==SET)
    {
        count++;
        EXTI_ClearITPendingBit(EXTI_Line0);
    }

}

//定义一个得到返回值的函数

uint8_t Get_count(void)
{
    return count;
}



