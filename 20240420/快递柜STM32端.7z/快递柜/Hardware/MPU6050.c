#include "stm32f10x.h"                  // Device header
#include "MyIIC.h"
#include "MPU6050_REG.h"
#include "MPU6050.h"

#define MPU6050_ADDR 0xD0               //MPU6050的位置




//先指定寄存器写
void MPU6050_WriteADDR(uint8_t RegADDR,uint8_t data)
{
    //先找到设备地址
    I2C_Start();//
    MyI2C_SendByte(MPU6050_ADDR);
    MyI2C_ReadACK();
    //找到设备寄存器地址
    MyI2C_SendByte(RegADDR);
    MyI2C_ReadACK();
//写数据
    MyI2C_SendByte(data);
    MyI2C_ReadACK();
    I2C_Stop();
}

//先指定寄存器读
uint8_t MPU6050_ReadADDR(uint8_t RegADDR)
{
    I2C_Start();//
    MyI2C_SendByte(MPU6050_ADDR);//
    MyI2C_ReadACK();//
    
    MyI2C_SendByte(RegADDR);//
    MyI2C_ReadACK();//
    
    //重新找到地址 读数据
    I2C_Start();
    MyI2C_SendByte(MPU6050_ADDR|0x01);//
    MyI2C_ReadACK();//
    //读取数据
    uint8_t recvdata=MyI2C_RecvByte();//
    //发送ACK非应答 
    MyI2C_SendACK(1);//
    I2C_Stop();//
    return recvdata;
}
//MPU6050初始化
void MPU6050_Init(void)
{
    MyI2C_Init();
      //配置MPU6050
  MPU6050_WriteADDR(MPU6050_REG_PWR_MGMT_1,0x01);//解除睡眠,设置陀螺仪的时钟  
  MPU6050_WriteADDR(MPU6050_REG_PWR_MGMI_2,0x00);//所有的加速度和陀螺仪xyz不待机
  MPU6050_WriteADDR(MPU6050_REG_SMPLRT_DIV,0x09);//分频10
  MPU6050_WriteADDR(MPU6050_REG_CONFIG,0x06);//滤波设置
  MPU6050_WriteADDR(MPU6050_REG_GYRO_CONFIG,0x18);//陀螺仪量程满配置 2000°/sec
  MPU6050_WriteADDR(MPU6050_REG_ACCEL_CONFIG,0x18);//加速度满量程 +- 16g
}

void MPU6050_Data(MPU6050_DataTypeDef *data)
{
    data->ACCEL_X=(int16_t)MPU6050_ReadADDR(MPU6050_ACCEL_XOUT_H)<<8 |(int16_t)MPU6050_ReadADDR(MPU6050_ACCEL_XOUT_L);
    data->ACCEL_Y=(int16_t)MPU6050_ReadADDR(MPU6050_ACCEL_YOUT_H)<<8 |(int16_t)MPU6050_ReadADDR(MPU6050_ACCEL_YOUT_L);
    data->ACCEL_Z=(int16_t)MPU6050_ReadADDR(MPU6050_ACCEL_ZOUT_H)<<8 |(int16_t)MPU6050_ReadADDR(MPU6050_ACCEL_ZOUT_L);
    data->GYRO_X=(int16_t)MPU6050_ReadADDR(MPU6050_GYRO_XOUT_H)<<8 |(int16_t)MPU6050_ReadADDR(MPU6050_GYRO_XOUT_L);
    data->GYRO_Y=(int16_t)MPU6050_ReadADDR(MPU6050_GYRO_YOUT_H)<<8 |(int16_t)MPU6050_ReadADDR(MPU6050_GYRO_YOUT_L);
    data->GYRO_Z=(int16_t)MPU6050_ReadADDR(MPU6050_GYRO_ZOUT_H)<<8 |(int16_t)MPU6050_ReadADDR(MPU6050_GYRO_ZOUT_L);
}
