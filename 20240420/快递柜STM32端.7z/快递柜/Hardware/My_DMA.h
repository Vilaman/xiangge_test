#ifndef _MYDMA_H
#define _MYDMA_H

void My_DMA_Init(void);



#endif
