#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include  "DHT11.h"

//最开始发送信号的输出模式
void DHT11_Mode_output(void)
{
    GPIO_InitTypeDef GPIO_DHT11;
    GPIO_DHT11.GPIO_Mode=GPIO_Mode_Out_PP;
    GPIO_DHT11.GPIO_Pin=GPIO_Pin_9;
    GPIO_DHT11.GPIO_Speed=GPIO_Speed_50MHz;
    GPIO_Init(GPIOA,&GPIO_DHT11);
}
 //当确认信号后的输入模式
void DHT11_Mode_input(void)
{
    GPIO_InitTypeDef GPIO_DHT11;
    GPIO_DHT11.GPIO_Mode=GPIO_Mode_IPU;
    GPIO_DHT11.GPIO_Pin=GPIO_Pin_9;
    GPIO_DHT11.GPIO_Speed=GPIO_Speed_50MHz;
    GPIO_Init(GPIOA,&GPIO_DHT11);
}

void DHT11_Init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
    DHT11_Mode_output();
    GPIO_SetBits(GPIOA,GPIO_Pin_9);
}

void DHT11_Start(void)
{
    DHT11_Mode_output();
    GPIO_ResetBits(GPIOA,GPIO_Pin_9);
    Delay_ms(18);
    GPIO_SetBits(GPIOA,GPIO_Pin_9);
    Delay_us(40);
}

uint8_t DHT11_ACK(void)
{
    
    DHT11_Mode_input();
    Delay_us(10);
    if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_9)==0){//表示设备开始响应
        while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_9)==0);//把剩下响应的数据消耗完
        while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_9)==1);
        return 1;
    }
    else//读不到设备响应
    {
        return 0;
    }
}

//读取每一位字节
uint8_t DHT11_ReadBit(void)
{
    while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_9)==0);//先消耗开始时候的0
    Delay_us(37);//小于12+26；
    if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_9))
    {
        while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_9)==1);
        return 1;
    }
    return 0;
}

uint8_t DHT11_BYTE(void)
{
    uint8_t bytenum=0x0;
    for(uint8_t i=1;i<=8;i++)
    {
        if(DHT11_ReadBit())
        {
            bytenum |= 0x1<<(8-i);
        }
    }
    return bytenum;
}

uint8_t DHT11_Getdata(DHT11_DATA *DHT11_data)
{
    DHT11_Start();
    if(DHT11_ACK())
        {
            DHT11_data->humi_int=DHT11_BYTE();
            DHT11_data->humi_float=DHT11_BYTE();
            DHT11_data->temp_int=DHT11_BYTE();
            DHT11_data->temp_float=DHT11_BYTE();
            DHT11_data->checkdata=DHT11_BYTE();
            return 1;
        }
    return 0;
}
