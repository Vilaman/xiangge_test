#ifndef _DHT11_H
#define _DHT11_H


//定义结构体
typedef struct{
    uint8_t humi_int;
    uint8_t humi_float;
    uint8_t temp_int;
    uint8_t temp_float;
    uint8_t checkdata;
}DHT11_DATA;

void DHT11_Init(void);
uint8_t DHT11_Getdata(DHT11_DATA *DHT11_data);


#endif
