#include "stm32f10x.h"                  // Device header

uint16_t arr[4];

void My_DMA_Init(void)
{
    
    //DMA开启时钟AHB
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);
    
    //初始化DMA
    DMA_InitTypeDef My_DMADef;
    My_DMADef.DMA_BufferSize=4;//转运的数据大小
    My_DMADef.DMA_DIR=DMA_DIR_PeripheralSRC;//数据传输方向，选择由外设到存储器
    My_DMADef.DMA_M2M=DMA_M2M_Disable;//存储器到存储器，选择使能
    My_DMADef.DMA_MemoryBaseAddr=(uint32_t)&arr;//存储器基地址
    My_DMADef.DMA_MemoryDataSize=DMA_MemoryDataSize_HalfWord;//外设数据宽度，选择字节
    My_DMADef.DMA_MemoryInc=DMA_MemoryInc_Enable;//存储器地址自增，选择使能
    My_DMADef.DMA_Mode=DMA_Mode_Circular;//模式，
    My_DMADef.DMA_PeripheralBaseAddr=(uint32_t)&ADC1->DR;//外设基地址
    My_DMADef.DMA_PeripheralDataSize=DMA_PeripheralDataSize_HalfWord;//外设数据宽度，选择字节
    My_DMADef.DMA_PeripheralInc=DMA_PeripheralInc_Disable;//外设地址自增
    My_DMADef.DMA_Priority=DMA_Priority_Medium;//优先级，选择中等
    
    DMA_Init(DMA1_Channel1,&My_DMADef);
    
    DMA_Cmd(DMA1_Channel1,ENABLE);

}

