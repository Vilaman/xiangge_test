#include "stm32f10x.h"                  // Device header


void Lightsenser_init(void){
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
    GPIO_InitTypeDef GPIO_LIGHT;
    GPIO_LIGHT.GPIO_Mode=GPIO_Mode_IPU;
    GPIO_LIGHT.GPIO_Pin=GPIO_Pin_5;
    GPIO_LIGHT.GPIO_Speed=GPIO_Speed_50MHz;
    GPIO_Init(GPIOA,&GPIO_LIGHT);
}

uint8_t LightStatusGet(void){

    if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_5))
    {
        return 1;
    }
    else
    {
        return 0;
    }

}
