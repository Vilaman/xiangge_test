#ifndef _INTERRUPT_H
#define _INTERRUPT_H



void Interrupt_Init(void);
uint8_t Get_count(void);







#endif
