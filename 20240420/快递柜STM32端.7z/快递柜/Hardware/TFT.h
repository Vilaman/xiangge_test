#ifndef _TFT_H
#define _TFT_H
#include "stm32f10x.h"                  // Device header


void TFT_SendDatas(uint8_t *data,uint16_t start,uint16_t length);
void Set_TFTArea(uint8_t ColoumnStart,uint8_t ColoumnEnd,uint8_t LineStart,uint8_t LineEnd);
void TFT_Init(void);
void TFT_clear(void);
void TFT_ShowImage(uint8_t coloumn,uint8_t line,uint8_t ImgHigh,uint8_t ImgWidth,uint8_t * Data);
void SetFill_Color(uint8_t coloumn,uint8_t row,uint8_t Heigth, uint8_t Width,uint16_t Color);

#endif
