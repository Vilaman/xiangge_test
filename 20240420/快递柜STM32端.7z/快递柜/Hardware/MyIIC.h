#ifndef _MYIIC_H
#define _MYIIC_H


void MyI2C_Init(void);
void My_I2C_SCLWrite(uint8_t bit);
void My_I2C_SDAWrite(uint8_t bit);
uint8_t MyI2C_ReadBit(void);
void I2C_Start(void);
void I2C_Stop(void);
void MyI2C_SendByte(uint8_t data);
uint8_t MyI2C_ReadACK(void);
uint8_t MyI2C_RecvByte(void);
void MyI2C_SendACK(uint8_t ACK);


#endif
